-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2018 at 11:19 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_20_may`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Aboualama', 'aa@gmail.com', '$2y$10$lkyWDpf9F7amr/ypmBRfp.xVp.GSBaI11/ZJRMT1Ny.VF3P0aCb.y', 'default.png', 'tTElDVb95vAKU85tN5Qag7NpQG83Ye6y6SLjdPxObkw3HAtB4Oq4cdb5v0T1', '2018-05-22 00:48:58', '2018-05-22 00:48:58'),
(2, 'aaaaa', 'aaaa@gmail.com', '$2y$10$DnXr4IzOLibqSxGTx11DuOO2JnDP8.qj5CaY9.suS6rbuGBaXrSUq', 'C:\\xampp\\tmp\\phpA080.tmp', 'pz5BiqCw73lwlIDki3TP7lCXlyxP9arQVfireqy0lZnQ0Cw50SvicGU3COv4', '2018-05-22 01:07:24', '2018-05-22 01:07:24'),
(3, 'Aboualama', 'aboualama@gmail.com', '$2y$10$P2bm49Lybp70dW6kHKlDK.E31Z5Dv.Q8VxRR2AY2AQQIr/97v6IvW', '1526958875.jpg', NULL, '2018-05-22 01:14:35', '2018-05-22 01:14:35');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `fax` int(11) NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `email`, `phone`, `fax`, `country`, `city`, `address`, `lat`, `lan`, `created_at`, `updated_at`) VALUES
(3, 'task@gmail.com', 1220185281, 5298688, 'Egypt', 'Alexandria', '1 Building El Mostaqbal cite  Victoria', '31.246644', '29.987057', '2018-05-22 15:50:22', '2018-05-23 17:18:56');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_05_22_004214_create_admins_table', 2),
(4, '2018_05_22_033308_create_contacts_table', 3),
(5, '2018_05_25_211816_create_settings_table', 4),
(6, '2018_05_27_220805_create_pages_table', 5),
(7, '2018_05_29_211816_create_socials_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `keywords`, `description`, `body`, `created_at`, `updated_at`) VALUES
(1, 'about us', 'aaaaaaa', 'aaaaaaa', '<p>aaaaaaa</p>', NULL, '2018-05-27 23:47:59'),
(3, 'call me', 'vvv ,  gjjhh ,  bbnvbnvb , vvvv', 'vvvvvvvv', '<p><a href=\"https://mobirise.co/h\">make a website</a></p>\r\n\r\n<h1>HTML5 Article Template</h1>\r\n\r\n<p><a href=\"https://mobirise.com/bootstrap-template/mobirise-free-template.zip\">FREE DOWNLOAD</a>&nbsp;<a href=\"https://mobirise.com/bootstrap-template/article-template.html#content5-11\">LIVE DEMO</a></p>\r\n\r\n<h2>BOOTSTRAP ARTICLE TEMPLATE</h2>\r\n\r\n<h3>Article header with background image and parallax effect</h3>\r\n\r\n<h2>Article Title with Solid Background</h2>\r\n\r\n<h3>Shape your future web project with sharp design and refine coded functions.</h3>\r\n\r\n<p><span dir=\"rtl\"><img alt=\"Mobirise\" src=\"https://mobirise.com/bootstrap-template/assets/images/laura-aziz-78171-2000x1337.jpg\" style=\"float:left; height:400px; width:698px\" title=\"\" /></span></p>\r\n\r\n<p><strong>Make your own website in a few clicks!</strong>Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface. Mobirise Website Builder creates responsive, retina and&nbsp;<em>mobile friendly websites</em>&nbsp;in a few clicks. Mobirise is one of the easiest website development tools available today.</p>\r\n\r\n<p><strong>Make your own website in a few clicks!</strong>&nbsp;Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface. Mobirise Website Builder creates responsive, retina and&nbsp;<em>mobile friendly websites</em>&nbsp;in a few clicks. Mobirise is one of the easiest website development tools&nbsp;<a href=\"https://mobirise.com/\">available</a>&nbsp;today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</p>\r\n\r\n<p>Make your own website in a few clicks! Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface. Mobirise Website Builder creates responsive, retina and mobile friendly websites in a few clicks. Mobirise is one of the easiest website development tools available today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</p>\r\n\r\n<p>Make your own website in a few clicks! Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface. Mobirise Website Builder creates responsive, retina and mobile friendly websites in a few clicks. Mobirise is one of the easiest website development tools available today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</p>\r\n\r\n<hr />\r\n<p>Mobirise is one of the easiest website development tools available today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</p>\r\n\r\n<hr />\r\n<hr />\r\n<p>Mobirise is one of the easiest website development tools available today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</p>\r\n\r\n<hr />\r\n<blockquote><strong>Make your own website in a few clicks!</strong>&nbsp;Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface. Mobirise Website Builder creates responsive, retina and&nbsp;<strong>mobile friendly websites</strong>&nbsp;in a few clicks. Mobirise is one of the easiest website development tools&nbsp;<a href=\"https://mobirise.com/\">available</a>today. It also gives you the freedom to develop as many websites as you like given the fact that it is a desktop app.</blockquote>\r\n\r\n<ol>\r\n	<li><strong>MOBILE FRIENDLY</strong>&nbsp;- no special actions required, all sites you make with Mobirise are mobile-friendly. You don&#39;t have to create a special mobile version of your site, it will adapt automagically.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n	<li><strong>EASY AND SIMPLE</strong>&nbsp;- cut down the development time with drag-and-drop website builder. Drop the blocks into the page, edit content inline and publish - no technical skills required.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n	<li><strong>UNIQUE STYLES</strong>&nbsp;- choose from the large selection of latest pre-made blocks - full-screen intro, bootstrap carousel, content slider, responsive image gallery with lightbox, parallax scrolling, video backgrounds, hamburger menu, sticky header and more.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li><strong>MOBILE FRIENDLY</strong>&nbsp;- o special actions required, all sites you make with Mobirise are mobile-friendly. You don&#39;t have to create a special mobile version of your site, it will adapt automagically.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n	<li><strong>EASY AND SIMPLE</strong>&nbsp;- cut down the development time with drag-and-drop website builder. Drop the blocks into the page, edit content inline and publish - no technical skills required.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n	<li><strong>UNIQUE STYLES</strong>&nbsp;- choose from the large selection of latest pre-made blocks - full-screen intro, bootstrap carousel, content slider, responsive image gallery with lightbox, parallax scrolling, video backgrounds, hamburger menu, sticky header and more.&nbsp;<a href=\"https://mobirise.com/\">Try it now!</a></li>\r\n</ul>', '2018-05-27 23:02:25', '2018-05-28 00:48:27');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('aboualama@gmail.com', '$2y$10$zAo.Si82Pc01HKM2/ohsP.aHiCmTebP0vx1FP1pYYZFfbVweD37AC', '2018-05-22 19:32:49');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'registration', 'registration', 'active', '2018-05-25 23:31:54', '2018-05-28 20:22:17'),
(2, 'page', 'view pages', 'active', '2018-05-26 15:12:50', '2018-05-28 20:14:17'),
(3, 'contact', 'contact page', 'active', '2018-05-26 15:13:46', '2018-05-29 18:20:47'),
(4, 'social', 'social links', 'active', '2018-05-26 20:38:21', '2018-05-29 14:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `name`, `link`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'facebook', 'http://www.facebook.com/profile.php?id=100026419680190', 'facebook', NULL, '2018-05-29 15:55:49'),
(2, 'aaa', NULL, 'user', '2018-05-29 15:59:09', '2018-05-29 16:01:45'),
(3, 'Twitter', 'https://twitter.com/', 'twitter', '2018-05-29 18:00:55', '2018-05-29 18:00:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `date`, `bio`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'nnnnn', 'nnnnnn', 'VARCHAR@ff.vv', '$2y$10$sxmJk9/XTiY4XJ3Ws90P1emGWLsH7KBUlmeyNhGo4qgisITT85Oqa', 'female', '2018-05-16', 'nnnnnnn', 'inactive', 'Kd1cHLE9lou51uMqxkR2PxrK5tDUWYJP05elV4vm1MnZOcbdoIRc91NcYZBI', '2018-05-21 00:24:54', '2018-05-21 00:24:54'),
(3, 'aaaaaaaa', 'aaaaaaaaaaaaaa', 'aboualama@mail.com', '$2y$10$fsQFh69AS79I08y2Lwno0.UOIKJ/Wv/3uLCLdtfvRAZN9vfd/zl1q', 'male', '2018-05-10', 'aaaaaaaaaaa', 'active', 'ZEeuNYUOWUtHl3Bbm69qJhnl0lKNhSlunu5UPyevONh0CSaQ5Dq5vv7UIq5Z', '2018-05-21 00:26:55', '2018-05-28 21:10:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contacts_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
