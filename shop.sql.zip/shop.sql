-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2018 at 10:48 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'aboualama', 'aboualama@gmail.com', '$2y$10$5q0kQK9hv/58Mu8.jDbk5.ftsz5luBXO6HFtUlSkj1Ck.VbP5KvOu', 'default.jpg', 'tdgzIBcXR0RVmUzg7u1oBsKdABMOAO6gSftr1IB34bOGiCKL1iCuQm2Z4nxu', '2018-07-31 17:45:04', '2018-07-31 17:45:04');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `keywords`, `img`, `created_at`, `updated_at`) VALUES
(1, 'aa', 'aaa', 'aaaa', 'aaa.ggg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Clothes', NULL, '2018-08-09 15:42:34'),
(2, 'Accessories', '2018-08-08 19:06:59', '2018-08-09 15:56:32'),
(3, 'Footwear & Bags', '2018-08-08 19:07:14', '2018-08-09 15:58:43');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `user_id`, `product_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'vcvccv', 1, 55, 'active', '2018-08-16 19:51:18', '2018-08-16 20:02:19'),
(2, 'aaaa aaaaaaa cccccc', 1, 42, 'inactive', '2018-08-16 22:59:40', '2018-08-16 22:59:40'),
(3, 'cccccccccccc', 1, 42, 'inactive', '2018-08-16 23:34:27', '2018-08-16 23:34:27'),
(4, 'cxvcb cbcvbcb', 1, 42, 'inactive', '2018-08-16 23:34:46', '2018-08-16 23:34:46'),
(5, 'aaaaaaaaaaaa', 1, 43, 'inactive', '2018-08-17 00:37:08', '2018-08-17 00:37:08'),
(6, 'zzzzzzzzzzzz', 1, 41, 'inactive', '2018-08-22 01:15:32', '2018-08-22 01:15:32'),
(7, 'task', 1, 56, 'inactive', '2018-08-24 20:02:20', '2018-08-24 20:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `fax` int(11) NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `email`, `phone`, `fax`, `country`, `city`, `address`, `lat`, `lan`, `created_at`, `updated_at`) VALUES
(1, 'Egypt@Egypt.com', 3333, 33333333, 'Egypt', 'Alex', 'Ibn Salamaa, As Soyouf Qebli (Include Izbat Derbanah), Qism El-Montaza, Alexandria Governorate, Egypt', '31.2465962221181', '29.98724205640258', '2018-08-10 15:09:37', '2018-08-10 16:05:41');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_05_22_004214_create_admins_table', 1),
(4, '2018_05_22_033308_create_contacts_table', 1),
(5, '2018_05_25_211816_create_settings_table', 1),
(6, '2018_05_27_220805_create_pages_table', 1),
(7, '2018_05_29_211816_create_socials_table', 1),
(8, '2018_07_23_205258_create_categories_table', 1),
(9, '2018_07_23_205327_create_brands_table', 1),
(10, '2018_07_23_205327_create_subcategories_table', 1),
(11, '2018_07_23_205526_create_products_table', 1),
(12, '2018_08_16_202155_create_comments_table', 2),
(13, '2018_08_20_013525_create_shoppingcart_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `keywords`, `description`, `body`, `created_at`, `updated_at`) VALUES
(1, 'About Us', 'About Us', 'About Us', '<p>About Us</p>\r\n\r\n<p dir=\"rtl\" style=\"text-align:center\"><a href=\"https://www.facebook.com/680320138769300/photos/pcb.1427057890762184/1427057624095544/?type=3\" id=\"u_fetchstream_2_6\" rel=\"theater\"><img alt=\"Image may contain: 2 people, people smiling, people sitting and child\" src=\"https://scontent-cai1-1.xx.fbcdn.net/v/t1.0-0/p526x296/40035420_1427057630762210_9052557317727322112_n.jpg?_nc_cat=0&amp;oh=f9a1d4ad321468463f821f2c1d4e6b9a&amp;oe=5C058A93\" style=\"height:500px; width:500px\" /></a></p>\r\n\r\n<p><a href=\"https://www.facebook.com/680320138769300/photos/pcb.1427057890762184/1427057737428866/?type=3\" id=\"u_fetchstream_2_7\" rel=\"theater\"><img alt=\"Image may contain: 2 people, sky and outdoor\" src=\"https://scontent-cai1-1.xx.fbcdn.net/v/t1.0-0/p261x260/39970289_1427057744095532_7401322823991427072_n.jpg?_nc_cat=0&amp;oh=ac1c506b2c5cfa5fcb680886a9a0faf3&amp;oe=5C3A123F\" style=\"float:right; height:368px; width:249px\" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>', '2018-08-24 21:00:43', '2018-08-24 21:00:43');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `subcategory_id` int(10) UNSIGNED NOT NULL,
  `brand_id` int(10) UNSIGNED DEFAULT NULL,
  `admin_id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `subcategory_id`, `brand_id`, `admin_id`, `photo`, `created_at`, `updated_at`) VALUES
(41, 'mobile', 'Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description Product description', 546, 5, 1, 1, '34.jpg', NULL, '2018-08-27 00:30:40'),
(42, 'mobile', 'Se6IzOCIpq', 179, 6, 1, 1, '40.jpg', NULL, NULL),
(43, 'mobile', 'LAaggRYkT1', 515, 2, 1, 1, '30.jpg', NULL, NULL),
(44, 'mobile', 'bwkgHKBUhE', 347, 5, 1, 1, '12.jpg', NULL, NULL),
(45, 'mobile', 'qy4ZEvVpp5', 566, 4, 1, 1, '29.jpg', NULL, NULL),
(46, 'mobile', 'm64qy5pWyW', 403, 4, 1, 1, '26.jpg', NULL, NULL),
(47, 'mobile', 'pCwiC10OWH', 868, 4, 1, 1, '37.jpg', NULL, NULL),
(48, 'mobile', 'c1LQFwguEC', 512, 2, 1, 1, '13.jpg', NULL, NULL),
(49, 'mobile', 'Xs9uRZBWE8', 857, 4, 1, 1, '27.jpg', NULL, NULL),
(50, 'mobile', 'Yye2FZpKdD', 642, 6, 1, 1, '14.jpg', NULL, NULL),
(51, 'mobile', 'fNKeOyagF9', 965, 2, 1, 1, '18.jpg', NULL, NULL),
(52, 'mobile', '7W3PzUmcBB', 110, 6, 1, 1, '12.jpg', NULL, NULL),
(53, 'mobile', 'UDMuKP0w41', 740, 4, 1, 1, '39.jpg', NULL, NULL),
(54, 'mobile', 'f47qXIEIgH', 615, 4, 1, 1, '35.jpg', NULL, NULL),
(55, 'mobile', 'KHCNosj3Wi', 808, 6, 1, 1, '33.jpg', NULL, NULL),
(56, 'mobile', 'fNoMLXlamF', 363, 2, 1, 1, '40.jpg', NULL, NULL),
(57, 'mobile', 'pdq0rOxKx9', 771, 3, 1, 1, '30.jpg', NULL, NULL),
(58, 'mobile', 'C9iFJMotYJ', 720, 6, 1, 1, '37.jpg', NULL, NULL),
(59, 'mobile', 'JRkFvwXFHH', 90, 3, 1, 1, '27.jpg', NULL, NULL),
(60, 'mobile', 'UBHtsRT39Q', 246, 2, 1, 1, '36.jpg', NULL, NULL),
(68, 'Aboualama', 'Dresses Dresses', 113, 2, 1, 1, '1535407258.jpg', '2018-08-27 20:00:58', '2018-08-27 20:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'brand', 'brand brand', 'active', '2018-07-31 17:50:11', '2018-07-31 17:50:11'),
(2, 'product', 'product product', 'active', '2018-07-31 18:00:52', '2018-08-15 22:23:13'),
(3, 'Subcategory', 'a', 'active', '2018-08-04 17:25:28', '2018-08-18 19:28:39'),
(4, 'Category', 'Category Category Category', 'active', '2018-08-08 19:05:59', '2018-08-18 19:29:05'),
(5, 'contact', 'contact', 'active', '2018-08-10 14:57:13', '2018-08-10 14:57:13'),
(6, 'registration', 'user', 'active', '2018-08-15 22:22:46', '2018-08-17 02:33:02'),
(7, 'comment', 'cccc', 'active', '2018-08-16 18:56:13', '2018-08-16 18:56:34'),
(8, 'e_commerce', 'e_commerce', 'active', '2018-08-22 00:13:05', '2018-08-22 00:57:06'),
(9, 'page', 'page', 'active', '2018-08-24 20:58:48', '2018-08-24 20:58:48'),
(10, 'social', 'social', 'active', '2018-08-25 23:33:05', '2018-08-25 23:33:05');

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shoppingcart`
--

INSERT INTO `shoppingcart` (`identifier`, `instance`, `content`, `created_at`, `updated_at`) VALUES
('1', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":1:{s:8:\"\0*\0items\";a:0:{}}', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci,
  `img` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `name`, `link`, `img`, `created_at`, `updated_at`) VALUES
(13, 'twitter', 'https://www.facebook.com/', NULL, '2018-08-26 17:53:28', '2018-08-26 22:48:56');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `r_img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `r_title` text COLLATE utf8mb4_unicode_ci,
  `l_img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_title` text COLLATE utf8mb4_unicode_ci,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `name`, `description`, `keywords`, `img`, `r_img`, `r_title`, `l_img`, `l_title`, `category_id`, `created_at`, `updated_at`) VALUES
(2, 'Dresses', 'Dresses Dresses', 'Dresses', '1533870403.jpg', 'dresses_r_image.jpg', '<p><span style=\"font-size:22px\">&nbsp;<span style=\"color:#f1c40f\"><strong>Dresses&nbsp;</strong></span><span style=\"color:#ffffff\">Dresses&nbsp;</span><span style=\"background-color:#999999\">Dresses</span></span></p>', 'dresses_l_image.jpg', '<blockquote>\r\n<p><span style=\"font-size:22px\">&nbsp;<span style=\"color:#f1c40f\"><strong>Dresses&nbsp;</strong></span><span style=\"color:#ffffff\">Dresses&nbsp;</span><span style=\"background-color:#999999\">Dresses</span></span></p>\r\n</blockquote>', 1, '2018-08-09 17:28:15', '2018-08-10 01:44:55'),
(3, 'Sweaters', 'Sweaters Sweaters Sweaters', 'Sweaters', '1533847064.jpg', NULL, NULL, NULL, NULL, 1, '2018-08-09 18:17:46', '2018-08-09 18:37:44'),
(4, 'Shorts & Skirts', 'Shorts & Skirts Shorts & Skirts Shorts & Skirts', 'Shorts & Skirts Shorts & Skirts Shorts & Skirts', '1533847107.jpg', NULL, NULL, NULL, NULL, 1, '2018-08-09 18:18:28', '2018-08-09 18:38:27'),
(5, 'Jeans', 'Jeans Jeans Jeans', 'Jeans Jeans Jeans', '1533847891.jpg', NULL, NULL, NULL, NULL, 1, '2018-08-09 18:19:02', '2018-08-09 18:51:31'),
(6, 'Shirts & Tops', 'Shirts & Tops', 'Shirts & Tops', '1533919840.jpg', 'shirts & tops_r_image.jpg', '<p><span style=\"font-size:36px\"><span style=\"color:#ffffff\">Witle </span><span style=\"color:#f1c40f\">Title </span><span style=\"color:#000000\">Ritle</span></span></p>', 'shirts & tops_l_image.jpg', '<p style=\"text-align:center\"><span style=\"font-size:36px\"><span style=\"color:#ffffff\">Witle </span><span style=\"color:#f1c40f\">Title </span><span style=\"color:#000000\">Ritle</span></span></p>', 1, '2018-08-09 18:19:40', '2018-08-10 14:50:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `date`, `bio`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'aAAAAAAA', 'AAAAAAAAAAAA', 'aboualama@gmail.com', '$2y$10$n5FTtQuCfYqnj3AAsE3ro.ZGR7Yc2AiX0SWAn7CAEmvGXwR8A9TwK', 'male', '2004-08-28', 'Vvvvvvvvvxxxxxxx', 'active', 'fMe39Bl2JoolNyxwqBiqaFpYBSRB3uEqAUKrMPTiQJuYIPXn5SRsSQFTuitr', '2018-08-16 00:08:22', '2018-08-25 19:02:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_product_id_foreign` (`product_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contacts_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_subcategory_id_foreign` (`subcategory_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`),
  ADD KEY `products_admin_id_foreign` (`admin_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD PRIMARY KEY (`identifier`,`instance`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcategories_category_id_foreign` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
